const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access');
const { error } = require('console');

let response = undefined;
let updateStatus = undefined;
exports.handler = async (event) => {

	var pool = mysql.createPool({
		host: db_access.config.host,
		user: db_access.config.user,
		password: db_access.config.password,
		database: db_access.config.database
	});

	
	let checkAccessKey = (key) => {
		
		return new Promise((resolve, reject) => {
			pool.query("SELECT * FROM vmAccessKeys WHERE accessKey=?;", [key], (error, rows) => {
					if(rows.length === 1){
						console.log("checked access Key");
						return resolve(1);
					}else{return reject (0);}
			});

		});

	};
	
	
	let changeStatus = (status, key) => {
		return new Promise((resolve, reject) => {
			pool.query("UPDATE vmAccessKeys SET isActive=? WHERE accessKey=?;", [status, key], (error, rows) => {
					return resolve(rows);
			});

		});

	};
	
	let checkOtherUser = (status) =>{
		if(status === 0){
			return 0;
		}
		
		else{
			return new Promise((resolve, reject) => {
				pool.query("SELECT accessKey FROM vmAccessKeys WHERE isActive = ?;",[1], (error, rows) => {
					if(rows.length > 0){
						console.log("this is the existing user:")
						console.log(rows[0].accessKey);
						return resolve(rows[0].accessKey);
					}else{
						return resolve (0);}
				});
			});
		}
	}
	
	let bootOtherUser = (key) => {
		return new Promise((resolve, reject) => {
			pool.query("UPDATE vmAccessKeys SET isActive = 0 WHERE accessKey=?;", [key], (error, rows) => {
				console.log("boot query:");
				console.log(rows);
					return resolve(1);
			});

		});

	};
	
	try{
		const changeAccessKey = await checkAccessKey(event.key);
		if(changeAccessKey === 0){
			throw "There is no VM with that access key.";
		}
		const otherUser = await checkOtherUser(event.setStatus);
		if(otherUser === 0){
			const updateStatus = await changeStatus(event.setStatus, event.key);
			
		}else {
			const bootedUser = await bootOtherUser(otherUser);
			if (bootedUser === 1){
				const updateStatus = await changeStatus(event.setStatus, event.key);
			}
		}
		response = {
			statusCode: 200,
			updateStatus
		}
	}
	
	catch (err) {
        response = {
          statusCode: 400,
          error: err
        }
	}
	
	finally{
	pool.end();   // done with DataBase
	}
	return response;
};