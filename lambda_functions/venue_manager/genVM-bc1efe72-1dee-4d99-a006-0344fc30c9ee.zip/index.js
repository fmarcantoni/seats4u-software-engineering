const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access');
const { error } = require('console');


exports.handler = async (event) => {

	var pool = mysql.createPool({
		host: db_access.config.host,
		user: db_access.config.user,
		password: db_access.config.password,
		database: db_access.config.database
	});

	let response = undefined;

	function genAccessKey(){
		return Math.floor(Date.now() / 1000)
	}
	
	const newAccessKey = await genAccessKey();
	
	let addAccessKey = () => {
		return new Promise((resolve, reject) => {

			pool.query("INSERT INTO vmAccessKeys(accessKey, isActive) VALUES(?, ?);", [newAccessKey, 0], (error, rows) => {
					if(rows === 1){
					return resolve(newAccessKey);}
					else{
						return resolve(error);
					}
			});

		});

	};

	let createNewVM = await addAccessKey();
	
	response = {
		statusCode: 200,
		newAccessKey
	}

	pool.end();   // done with DataBase
	return response;
};